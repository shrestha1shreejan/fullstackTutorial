﻿using Microsoft.AspNetCore.Http;
using System;

namespace DatingApp.Dtos
{
    public class PhotoForCreationDto
    {
        public string Url { get; set; }
        public IFormFile File { get; set; }
        public string Description { get; set; }
        public DateTime DateAdded { get; set; }
        public string PublicId { get; set; }

        public PhotoForCreationDto()
        {
            // adding automatic date time for the photos added
            DateAdded = DateTime.Now;
        }
    }
}
